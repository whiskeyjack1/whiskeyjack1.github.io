<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class artisantype extends Model
{
  protected $fillable=[
      'artisantype','image'
  ];


}
