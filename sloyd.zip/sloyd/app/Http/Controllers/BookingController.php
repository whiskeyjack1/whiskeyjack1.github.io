<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class BookingController extends Controller
{
    public function __construct() {

    }

    public function all() {
        return view('Bookings.index');
    }

    public function complete() {
        return view('Bookings.completed');
    }
    public function cancelled(){
        return view ('Bookings.cancelled');
    }
    public function onprocessing(){
        return view ('Bookings.onprocessing');
    }
    public function store(Request $request) {

    }
}
