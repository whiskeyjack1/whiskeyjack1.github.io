<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class RegionController extends Controller
{
    public function __construct() {

    }


    public function store(Request $request) {

    }
    public function all(){
        return view('region.new');
    }
    public function view(){
        return view('region.view');
    }
}
