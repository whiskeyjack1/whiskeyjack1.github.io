<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class ArtisanTypeController extends Controller
{
    public function __construct() {

    }

    public function list() {
        return view('ArtisanType.view');
    }

    public function create() {
        return view('ArtisanType.create');
    }

    public function store(Request $request) {

    }
}
