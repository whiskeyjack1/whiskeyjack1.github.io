<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class ArtisanController extends Controller
{
    public function __construct() {

    }

    public function all() {
        return view('artisans.index');
    }

    public function create() {
        return view('artisans.new');
    }

    public function store(Request $request) {

    }
}
