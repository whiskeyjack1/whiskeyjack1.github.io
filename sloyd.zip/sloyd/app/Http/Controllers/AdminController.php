<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class AdminController extends Controller
{

    public function __construct() {
        // return $this->middleware('auth');
    }
    
    public function index() {
        return view('admin.dashboard');
    }

    public function showMap() {
        return view('admin.maps');
    }

    public function getRequests() {
        return view('admin.requests');
    }

    public function showpayment() {
        return view('admin.payments');
    }

    public function showpromocode() {
        return view('admin.promo');
    }

    public function set() {
        return view('admin.settings');
    }

   
    

}
